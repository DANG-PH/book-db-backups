--
-- PostgreSQL database dump
--

\restrict NRH0HNfj5lF0n1BSH4JhbwSjYCmKOEy0oVejenhtNhMHPlcolaQbyyQdnQ60uWT

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: author_locks; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.author_locks (
    author character varying NOT NULL,
    "passwordHash" character varying NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.author_locks OWNER TO admin;

--
-- Name: book_quotes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.book_quotes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "bookId" uuid NOT NULL,
    text text NOT NULL,
    page integer,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.book_quotes OWNER TO admin;

--
-- Name: book_reviews; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.book_reviews (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "bookId" uuid NOT NULL,
    author character varying NOT NULL,
    rating integer,
    review text,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.book_reviews OWNER TO admin;

--
-- Name: books; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.books (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "categoryId" uuid NOT NULL,
    num character varying,
    year integer,
    title character varying NOT NULL,
    author character varying,
    blurb text,
    tags text,
    "fileUrl" character varying NOT NULL,
    "fileOriginalName" character varying,
    "coverUrl" character varying,
    note text,
    "readStatus" character varying,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "favoritedBy" text,
    "startedAt" timestamp with time zone,
    "finishedAt" timestamp with time zone
);


ALTER TABLE public.books OWNER TO admin;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    slug character varying NOT NULL,
    title character varying NOT NULL,
    dewey character varying,
    range character varying,
    intro text,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.categories OWNER TO admin;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "sessionId" uuid NOT NULL,
    role character varying NOT NULL,
    text text NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO admin;

--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.chat_sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_sessions OWNER TO admin;

--
-- Name: diary_entries; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.diary_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    author character varying NOT NULL,
    title character varying,
    content text NOT NULL,
    mood character varying,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "likedBy" text,
    "isPrivate" boolean DEFAULT false NOT NULL,
    "photoUrl" character varying
);


ALTER TABLE public.diary_entries OWNER TO admin;

--
-- Name: memories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.memories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description text,
    "memoryDate" date,
    "photoUrl" character varying,
    "addedBy" character varying,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "youtubeId" character varying,
    "likedBy" text
);


ALTER TABLE public.memories OWNER TO admin;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    text text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO admin;

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.push_subscriptions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO admin;

--
-- Name: reminder_state; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.reminder_state (
    id integer DEFAULT 1 NOT NULL,
    "lastStalledBookAt" timestamp with time zone,
    "lastQuietDiaryAt" timestamp with time zone,
    "lastQuoteResurfaceAt" timestamp with time zone
);


ALTER TABLE public.reminder_state OWNER TO admin;

--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.site_settings (
    id integer DEFAULT 1 NOT NULL,
    "siteTitle" character varying DEFAULT 'Thư Viện'::character varying NOT NULL,
    "curatorName" character varying,
    "curatorRole" character varying,
    "curatorPhoto" character varying,
    "updatedLabel" character varying,
    "partnerName" character varying DEFAULT 'Vy'::character varying NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.site_settings OWNER TO admin;

--
-- Data for Name: author_locks; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.author_locks (author, "passwordHash", "createdAt") FROM stdin;
me	$2b$10$ugp7ocC6SMQczzlCQXhENOJ7jVxA/CFj4EzK2NYoSjcUxhgAv0osG	2026-08-20 09:59:54.260554+00
\.


--
-- Data for Name: book_quotes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.book_quotes (id, "bookId", text, page, "createdAt") FROM stdin;
bcbd3bc5-22a1-490f-89c4-4e60af0b1b60	fedecc45-fe11-4c29-98db-431d98291ef3	Một hệ thống tốt được định nghĩa bởi 3 yếu tố\n- Độ tin cậy (Reliable)\n- Khả năng mở rộng (Scalable)\n- Tính dễ dàng khi bảo trì (Maintainable)	\N	2026-08-21 17:29:03.684182+00
f0465122-ca19-4ca8-8ab2-d3e126fedb90	0d3de3cd-be55-42b9-9203-782461353583	Nếu biết trăm năm là hữu hạn\nCớ sao ta không sống thật sâu	\N	2026-08-21 17:30:16.966774+00
11710a5c-c7b9-4ddd-8ae8-e8082fd5bd01	2df5efdc-5638-4be3-aba5-238a1d21e120	Tài sản của một người không nằm trong số tiền anh ta đang có trong túi; nó ở nguồn thu nhập anh ta tạo ra – dòng tiền liên tục chảy vào túi anh ta.	\N	2026-08-21 17:33:31.804868+00
8790294e-be6c-4722-af8f-10c62557d7ef	2df5efdc-5638-4be3-aba5-238a1d21e120	Một phần của tất cả những gì bạn kiếm được là của bạn để giữ lại.	\N	2026-08-21 17:35:10.5628+00
1bf658ea-9600-4d30-85aa-8517c748fb58	e5b1f19b-3016-45fb-9abc-f4e97775ceb9	Mọi người bảo Ove rằng ông chỉ nhìn đời theo hai màu đen trắng. Còn bà là màu sắc. Tất cả màu sắc của ông	\N	2026-08-21 17:38:33.566107+00
9d61e33b-0e02-48ea-aa4c-08ddb5dcf800	cb63559a-f560-4317-844b-e83aa93c3137	Lịch sử là gì? Chỉ là một ít ngụy tạo được biến thành những sự thật quan trọng.	\N	2026-08-25 08:37:00.319438+00
\.


--
-- Data for Name: book_reviews; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.book_reviews (id, "bookId", author, rating, review, "createdAt") FROM stdin;
43d0be82-5beb-4259-b9f5-504ea358e581	fedecc45-fe11-4c29-98db-431d98291ef3	me	5	hiii	2026-08-21 15:29:37.414989+00
7bae2264-1afc-4a11-b0d3-e4f1ba3f44e0	2df5efdc-5638-4be3-aba5-238a1d21e120	me	1	Tui chưa đọc nên cho 1 sao nha	2026-08-21 16:02:59.020211+00
266e984f-7811-4001-9d66-764c4e5ebc26	2df5efdc-5638-4be3-aba5-238a1d21e120	me	2	hay nhaa	2026-08-21 16:11:13.453219+00
96eaca68-d710-443c-8877-0b0a1504b7cd	e5b1f19b-3016-45fb-9abc-f4e97775ceb9	me	5	okay	2026-08-21 17:16:34.903139+00
8aadf560-5d1c-496b-8974-7f7ee74eefa1	0d3de3cd-be55-42b9-9203-782461353583	me	4	\N	2026-08-21 17:30:32.387949+00
ff1f06f8-b3bf-48a8-9bf5-99c199c3ae22	2df5efdc-5638-4be3-aba5-238a1d21e120	me	5	Hai Dang	2026-08-21 17:31:07.982088+00
eb1fa997-14f3-42f9-9064-9ef5b1b35eb4	cb63559a-f560-4317-844b-e83aa93c3137	me	5	5 sao nhé	2026-08-25 08:36:01.755539+00
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.books (id, "categoryId", num, year, title, author, blurb, tags, "fileUrl", "fileOriginalName", "coverUrl", note, "readStatus", "createdAt", "updatedAt", "viewCount", "favoritedBy", "startedAt", "finishedAt") FROM stdin;
be4f3cc4-b81b-4913-a2fb-abac48068315	7eb5c685-d718-4a43-9fe4-ad6d31894e8b	01	1936	Đắc Nhân Tâm	Dale Carnegie	Đắc Nhân Tâm thuộc thể loại sách kỹ năng sống và phát triển bản thân (self-help), do tác giả Dale Carnegie chắp bút và được xuất bản lần đầu tiên vào năm 1936. Cuốn sách là cẩm nang nghệ thuật thu phục lòng người, dạy cách giao tiếp, ứng xử và thấu hiểu con người để tạo dựng các mối quan hệ tốt đẹp, mang lại thành công và hạnh phúc trong cuộc sống	Giao tiếp,lòng người	books/0175e224-3ba9-435f-9c40-08a53ba63084.pdf	DacNhanTam.pdf	https://firstnews.vn/upload/products/original/-1726817123.jpg	Cuốn sách ứng xử, giao tiếp cơ bản mà tớ hay đọc	done	2026-08-14 05:20:21.192211+00	2026-08-21 17:24:46.673881+00	1	me	\N	\N
70645786-5641-4844-842d-4db9a5b3bae1	c3804353-1ee5-4310-82b6-e45c48fa5b10	03	1878	Không gia đình	Hector Malot	Rémi bị bỏ rơi từ nhỏ, lớn lên cùng người mẹ nuôi nghèo, rồi theo cụ già Vitali đi biểu diễn xiếc rong khắp nước Pháp. Tác phẩm ca ngợi nghị lực sống, lòng dũng cảm, tình người ấm áp và tình bạn qua những gian truân.	Lòng người	books/aeb29a7d-ecc3-4fd2-9fa2-45291262427f.pdf	KhÃ´ng Gia ÄÃ¬nh.pdf	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1DWVy9xgEQ9SqveSOjX2qX4CZ9UZ74NMLuypB3LPHm6Rk54PopKEPjvTu&s=10	Cuốn sách này giúp ta hiểu được về sự thấu hiểu và sẻ chia, tình yêu thương vô điều kiện và ý nghĩa của gia đình	done	2026-08-14 05:20:21.192211+00	2026-08-21 17:40:51.27978+00	2	\N	\N	\N
9be6e684-b294-45b3-a436-b32ee6e846a2	7eb63b83-a59e-4550-b7b9-eb1fce9221c7	02	2011	Nghệ Thuật Tư Duy Rành Mạch	Rolf Dobelli	99 thiên kiến và lỗi tư duy phổ biến, mỗi cái gói gọn trong vài trang — từ thiên kiến xác nhận đến ngụy biện chi phí chìm — giúp nhận diện những cái bẫy logic vẫn âm thầm điều khiển quyết định hằng ngày.	COG,PSY	books/7cdf6232-5722-463e-8736-2e368eeb567e.pdf	\N	https://dongkhoi.baovinhlong.vn/image/fckeditor/upload/2020/20200213/images/bia-sach.jpg	\N	want	2026-08-14 05:20:21.192211+00	2026-08-21 16:55:15.12495+00	1	me	\N	\N
5503ab6d-86a0-45cd-85ab-9baf992cc38d	7eb63b83-a59e-4550-b7b9-eb1fce9221c7	01	1946	Đi Tìm Lẽ Sống	Viktor E. Frankl	Hồi ký của một bác sĩ tâm thần sống sót qua trại tập trung Đức Quốc xã, và học thuyết liệu pháp ý nghĩa (logotherapy) được rút ra từ chính trải nghiệm đó — con người có thể chịu đựng gần như mọi nghịch cảnh nếu tìm được lý do để sống.	PHIL,SELF	books/46acbe9a-b92f-484b-9841-37505bc26658.pdf	\N	https://dtv-ebook.com.vn/images/Cover/37976065786_a63facf8de_o.jpg	\N	want	2026-08-14 05:20:21.192211+00	2026-08-21 16:55:18.703145+00	1	me	\N	\N
31d7cf38-a451-459e-8bb7-3b6808439369	7eb63b83-a59e-4550-b7b9-eb1fce9221c7	03	1995	Trí Tuệ Xúc Cảm	Daniel Goleman	Cuốn sách đặt nền móng cho khái niệm EQ. Lập luận rằng khả năng nhận biết, điều tiết cảm xúc và thấu cảm với người khác quan trọng cho thành công và hạnh phúc không kém, thậm chí hơn, chỉ số IQ.	PSY,SELF	books/362167db-4346-4609-a545-c645f31462da.pdf	\N	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKSEZUp55cZdn7H0L6NaBod-tzlNFaDuT6cll75awoITD4U0hPKfDS5vyM&s=10	\N	want	2026-08-14 05:20:21.192211+00	2026-08-21 17:15:15.706952+00	3		\N	\N
d3f37ea8-33a2-4e01-9c0a-c9598a7606d2	7eb63b83-a59e-4550-b7b9-eb1fce9221c7	04	2011	Tư Duy Nhanh Và Chậm	Daniel Kahneman	Hai hệ thống tư duy song song trong não bộ — một nhanh, bản năng, cảm tính; một chậm, có chủ đích, logic — và cách sự tương tác giữa chúng định hình mọi phán đoán, thành kiến và quyết định của con người.	COG,PSY	books/5f33b005-b696-4f19-b7e0-73d65f9f0374.pdf	\N	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsy9HzK-whg8tVUZvZa3ltvEx1Xr6WgzjgPyY00wqvr9YuTnN_8ttGOVf-&s=10	\N	want	2026-08-14 05:20:21.192211+00	2026-08-20 03:36:41.359351+00	0	\N	\N	\N
0ce816b6-90ea-4ce6-9297-9abc104332ad	c3804353-1ee5-4310-82b6-e45c48fa5b10	01	2012	Điều kỳ diệu của tiệm tạp hóa Namiya	Higashino Keigo	Truyện xoay quanh ba thanh niên lang thang là Atsuya, Shota và Kouhei. Sau một vụ trộm, họ lẩn trốn vào một tiệm tạp hóa cũ kỹ đã bỏ hoang từ lâu.\r\nBất ngờ, một bức thư từ quá khứ được gửi vào khe cửa của tiệm, chứa đựng tâm sự và câu hỏi xin lời khuyên của một người xa lạ sống ở nhiều thập kỷ trước. Ba chàng trai quyết định viết thư hồi đáp. Càng trả lời, họ càng nhận ra tiệm tạp hóa này có khả năng kết nối thời gian kỳ lạ. Những lời tư vấn của họ không chỉ giúp gỡ rối bế tắc cho những mảnh đời ở quá khứ mà còn giúp chính ba kẻ lang thang tìm lại ý nghĩa và hướng đi cho cuộc đời mình.\r\nCuốn sách mang đến thông điệp ấm áp rằng lòng tốt, sự chân thành và kết nối giữa người với người có sức mạnh xoa dịu mọi tổn thương.	Giả tưởng,nhân văn,chữa lành.	books/717f1a44-40e5-4ae8-acaf-f449d14b28af.pdf	namiya.pdf	https://dtv-ebook.com.vn/images/truyen-online/ebook-dieu-ky-dieu-cua-tiem-tap-hoa-namiya-full-prc-pdf-epub-azw3.jpg	Cuốn sách cho ta thấy sự thấu hiểu và trách nhiệm với quyết định của bản thân	done	2026-08-14 05:20:21.192211+00	2026-08-21 17:40:54.77644+00	1		\N	\N
769534db-4372-4528-a7b6-f01569df6296	edb208aa-26bf-4902-9f71-25cbca52adad	01	2009	Clean Code	Robert C. Martin	Cuốn sách dạy cách viết mã nguồn (code) sao cho rõ ràng, mạch lạc và dễ đọc để người khác hoặc chính bạn có thể hiểu, sửa chữa và nâng cấp sau này. Tác giả chỉ ra sự khác biệt giữa code tốt và code xấu thông qua các quy tắc đặt tên, cách viết hàm ngắn gọn và cấu trúc chương trình hợp lý. Sách giúp nâng cao tư duy làm nghề, biến việc lập trình từ một công việc viết mã chạy được thành một nghệ thuật tạo ra sản phẩm chất lượng cao	Lập trình	books/4065daea-30d9-45c3-995c-9dfea0c24b38.pdf	clean-code (1).pdf	https://product.hstatic.net/200000273991/product/58_d061b86ab1274412a953933204357450_master.png	\N	want	2026-08-14 05:20:21.192211+00	2026-08-21 14:44:56.887934+00	0	\N	\N	\N
fedecc45-fe11-4c29-98db-431d98291ef3	edb208aa-26bf-4902-9f71-25cbca52adad	02	2017	Designing Data-Intensive Applications	Martin Kleppmann	Data is at the center of many challenges in system design today. Difficult issues need to be figured out, such as scalability, consistency, reliability, efficiency, and maintainability. In addition, we have an overwhelming variety of tools, including relational databases, NoSQL datastores, stream or batch processors, and message brokers. What are the right choices for your application? How do you make sense of all these buzzwords?\r\n\r\nIn this practical and comprehensive guide, author Martin Klepp	\N	books/466e99e2-e59c-4952-93d2-f74f9235c699.pdf	Martin-Kleppmann---Designing-Data-Intensive-Applications_-OâReilly-Media-(2017).pdf	https://covers.openlibrary.org/b/id/8434671-M.jpg	Cuốn sách chỉ lối cho tớ về thiết kế và vận hành hệ thống	reading	2026-08-14 05:20:21.192211+00	2026-08-22 14:04:42.007451+00	2	\N	\N	\N
5698ddb6-f1b6-462d-b243-00087276e16e	c3804353-1ee5-4310-82b6-e45c48fa5b10	04	2003	Người đua diều	Khaled Hosseini	Nội dung xoay quanh Amir, một cậu bé thuộc tầng lớp thượng lưu tại thủ đô Kabul của Afghanistan, và Hassan, người bạn thân thiết cũng là con trai người hầu trong gia đình. Sự hèn nhát của Amir trong một biến cố thời thơ ấu đã khiến cậu phản bội Hassan, để rồi nỗi dằn vặt ấy đeo bám theo cậu suốt những năm tháng di cư sang Mỹ, cho đến khi một cuộc gọi từ quá khứ thúc đẩy Amir quay trở lại quê hương đầy bom đạn để dũng cảm dấn thân vào hành trình chuộc lỗi và tìm lại sự thanh thản trong tâm hồn.	Tiểu thuyết văn học	books/00ca3aac-e54c-4140-9d47-652f7834bf02.pdf	14467-nguoi-dua-dieu-thuviensach.vn.pdf	https://upload.wikimedia.org/wikipedia/vi/6/6e/Nguoiduadieu.jpg?utm_source=vi.wikipedia.org&utm_campaign=index&utm_content=original	"Cuốn sách chạm đến những góc khuất sâu thẳm của tâm hồn, nhắc nhở chúng ta rằng sự tha thứ bắt đầu từ việc dám đối diện với quá khứ và sự hèn nhát tuổi trẻ."	done	2026-08-20 03:20:51.485786+00	2026-08-25 16:28:29.49433+00	1		\N	2026-08-25 16:28:29.489+00
e5b1f19b-3016-45fb-9abc-f4e97775ceb9	c3804353-1ee5-4310-82b6-e45c48fa5b10	02	2012	Người đàn ông mang tên Ove	Fredrik Backman	Cuốn sách kể về Ove, một ông lão 59 tuổi cộc cằn, khó tính và luôn tuân thủ nguyên tắc đến mức cực đoan. Sau khi người vợ quá cố qua đời và ông mất việc, Ove thấy cuộc đời chẳng còn ý nghĩa và lên kế hoạch tự tử. Thế nhưng, những kế hoạch ấy liên tục bị phá hỏng bởi sự xuất hiện bất ngờ của những người hàng xóm mới lắm chuyện. Qua những va chạm thường ngày, lớp vỏ bọc lạnh lùng của Ove dần tan vỡ, hé lộ một trái tim nhân hậu và mang đến cho người đọc bài học sâu sắc về tình người, sự sẻ chia và cách kết nối lại với thế giới xung quanh	Tình cảm,chữa lành	books/0988d304-8328-4bea-b52c-99baf9f08346.pdf	nguoi-dan-ong-mang-ten-ove.pdf	https://www.nxbtre.com.vn/Images/Book/nxbtre_full_24492022_034918.jpg	Cuốn tiểu thuyết hay về sự yêu thương và sự gắn kết	done	2026-08-14 05:20:21.192211+00	2026-08-21 17:40:57.963888+00	1	\N	\N	\N
0d3de3cd-be55-42b9-9203-782461353583	7eb63b83-a59e-4550-b7b9-eb1fce9221c7	05	2012	Nếu biết trăm năm là hữu hạn	Phạm Lữ Ân	Nếu biết trăm năm là hữu hạn là tập tản văn nổi tiếng của tác giả Phạm Lữ Ân. Sách gồm 40 bài viết nhẹ nhàng về gia đình, tình yêu và tuổi trẻ. Tác phẩm mang thông điệp cốt lõi: đời người ngắn ngủi, hãy trân trọng hiện tại và sống thật sâu sắc.	Truyền cảm hứng	books/cb9eebf8-7b46-4a40-bb24-147686fb9e2b.pdf	5010-neu-biet-tram-nam-la-huu-han-thuviensach.vn.pdf	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNer5WozVIO_ZI1Er_d85DYxOPT894wRNEq28AwmNg_lhOAe6tvUrvbCI&s=10	Cuốn sách này giúp mình trân trọng từng khoảnh khắc hiện tại và tìm thấy sự bình yên nội tại	want	2026-08-14 05:20:21.192211+00	2026-08-21 17:15:17.686481+00	1	\N	\N	\N
2df5efdc-5638-4be3-aba5-238a1d21e120	eb1e5e59-b36b-4d85-967a-3de60880f2d3	01	1926	Người Giàu Nhất Thành Babylon	George Samuel Clason	Cuốn sách mượn bối cảnh cổ xưa của vương quốc Babylon thịnh vượng để truyền tải những bài học quản lý tài chính hiện đại. Thay vì đưa ra các công thức khô khan, tác giả sử dụng các câu chuyện ngụ ngôn dễ hiểu xoay quanh nhân vật chính tên là Arkad – từ một người thợ khắc chữ nghèo khổ đã vươn lên thành người giàu có nhất thành Babylon.	Tài chính	books/3409748a-b719-4a64-ac54-fe6350995c9c.pdf	381-nguoi-giau-co-nhat-thanh-babylon-thuviensach.vn.pdf	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT3od5ZDzckm7VPL6AA-tbKZWfGIzJ_vxsfdpEbpb068LcJoVdm_UXnmIM&s=10	Cuốn sách này phù hợp với bất kỳ ai muốn bắt đầu học cách quản lý tài chính cá nhân từ những bước cơ bản nhất	want	2026-08-21 11:20:12.300118+00	2026-08-22 09:41:42.421391+00	21	me	\N	\N
5a579dcf-a51e-4451-9d8c-45a52cc98a3c	c3804353-1ee5-4310-82b6-e45c48fa5b10	05	2011	Trường Ca Achilles	Madeline Miller	Nội dung câu chuyện được kể lại qua góc nhìn của Patroclus – một hoàng tử phàm nhân lưu vong có phần vụng về – xoay quanh mối tình sâu đậm và đầy bi tráng giữa chàng với Achilles, người anh hùng vĩ đại nhất của Hy Lạp. Từ thuở niên thiếu gắn bó bên nhau tại Phthia cho đến khi bị cuốn vào cuộc chiến đẫm máu tại thành Troy, hành trình của hai chàng trai là sự giằng xé giữa tình yêu đôi lứa và lời tiên tri nghiệt ngã của các vị thần, kết thúc bằng cái chết định mệnh nhưng cũng chính là sự vĩnh cửu hóa tình cảm mà họ dành cho nhau.	Tiểu thuyết văn học	books/bda4c36b-8990-4caf-8265-d162301ced58.pdf	12921-truong-ca-achilles-thuviensach.vn.pdf	https://bizweb.dktcdn.net/thumb/1024x1024/100/576/749/products/2148aa1f-1abf-4453-8942-33a1a2ffd77a.jpg?v=1773128068430	Vẻ đẹp của sự đồng cảm và tình yêu chân thành, qua đó giúp người đọc thấu hiểu sâu sắc hơn về bi kịch của số phận và sức mạnh của trái tim con người trước lằn ranh sinh tử.	want	2026-08-20 03:25:48.36648+00	2026-08-22 08:04:16.066378+00	3	me	\N	\N
b68588a1-9108-4343-a710-ea3e953809f3	c3804353-1ee5-4310-82b6-e45c48fa5b10	06	1813	Kiêu hãnh và định kiến	Jane Austen	Câu chuyện xoay quanh nhân vật Elizabeth Bennet, một cô gái thông minh và sắc sảo trong một gia đình trung lưu có năm chị em gái tại nước Anh thế kỷ XIX. Khi chàng quý tộc giàu có và kiêu kỳ Mr. Darcy xuất hiện, những ấn tượng ban đầu đầy ác cảm cùng sự hiểu lầm đã tạo nên bức tường ngăn cách giữa họ. Trải qua nhiều biến cố và sự trưởng thành trong nhận thức, Elizabeth dần nhận ra bản chất tốt đẹp đằng sau vỏ bọc lạnh lùng của Darcy, trong khi Darcy cũng tự sửa đổi sự kiêu hãnh của mình, để rồi cuối cùng họ vượt qua mọi định kiến giai cấp để đến với một cái kết viên mãn bằng tình yêu đích thực.	Tình cảm,Tiểu Thuyết	books/90511b16-a4bc-4931-97c7-9ce4144086cd.pdf	10374-kieu-hanh-va-dinh-kien-thuviensach.vn.pdf	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfa5t8M18PNZPSvPusHXRIOT33vZ7a5DeD1Y58o9Gh2g&s=10	Thức tỉnh con người về cách nhìn nhận bản thân và người khác, giúp ta vượt qua những lăng kính chủ quan, sự kiêu ngạo vô căn cứ để chạm tới tình yêu chân thật và sự thấu hiểu lẫn nhau.	want	2026-08-20 03:33:21.698403+00	2026-08-22 07:21:45.342986+00	3	me	\N	\N
cb63559a-f560-4317-844b-e83aa93c3137	53c1c943-bc78-4b46-bc06-c5b3a5ee87d5	01	2011	Sapiens: Lược Sử Loài Người	Yuval Noah Harari	Nội dung cốt lõi của tác phẩm tái hiện hành trình tiến hóa dài 70.000 năm của loài người, từ một loài linh trưởng bình thường trên đồng cỏ châu Phi vươn lên thống trị toàn cầu nhờ bốn cuộc cách mạng vĩ đại gồm Cách mạng Nhận thức, Cách mạng Nông nghiệp, sự thống nhất của nhân loại và Cách mạng Khoa học. Tác giả giải thích cách mà khả năng sángtạo ra những trật tự tưởng tượng bằng ngôn ngữ hư cấu như tôn giáo, tiền tệ hay luật pháp đã giúp hàng triệu cá thể xa lạ có thể chung sống và hợp tác với nhau trên một quy mô lớn chưa từng có.	Lịch Sử,Văn Hóa	books/d808c5a7-120c-4a33-bdb3-0ec3592abfd3.pdf	1695-sapiens-luoc-su-loai-nguoi-thuviensach.vn.pdf	https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRashGWWXM6G2ZxcUSf4PgQl914G8D4hcLA4nMSJdel_Q&s=10	Tác phẩm mang lại góc nhìn đột phá giúp người đọc thoát khỏi những lối mòn tư duy truyền thống về lịch sử, từ đó thấu hiểu sâu sắc bản chất của xã hội cũng như những cái giá mà nhân loại phải trả trên con đường phát triển	want	2026-08-25 08:33:12.097267+00	2026-08-25 08:40:26.995433+00	1	me	\N	\N
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.categories (id, slug, title, dewey, range, intro, "position", "createdAt", "updatedAt") FROM stdin;
edb208aa-26bf-4902-9f71-25cbca52adad	tech	Công nghệ	005	000–099	Phần mềm. hệ thống phân tán, và những ý tưởng hay.	1	2026-08-14 05:20:21.192211+00	2026-08-14 05:20:21.192211+00
7eb5c685-d718-4a43-9fe4-ad6d31894e8b	ky-nang-song	Kỹ Năng Sống	\N	\N	\N	0	2026-08-14 05:20:21.192211+00	2026-08-14 05:20:21.192211+00
7eb63b83-a59e-4550-b7b9-eb1fce9221c7	eq	Trí Tuệ Cảm Xúc	158.2	100–199	Giao tiếp, lắng nghe, và thấu hiểu.	0	2026-08-15 05:20:21.192211+00	2026-08-14 05:20:21.192211+00
c3804353-1ee5-4310-82b6-e45c48fa5b10	tieu-thuyet-van-hoc	Tiểu Thuyết Văn Học	\N	\N	\N	2	2026-08-16 05:20:21.192211+00	2026-08-14 05:20:21.192211+00
eb1e5e59-b36b-4d85-967a-3de60880f2d3	tai-chinh	Tài chính	\N	\N	\N	0	2026-08-21 11:17:22.245381+00	2026-08-21 11:17:22.245381+00
53c1c943-bc78-4b46-bc06-c5b3a5ee87d5	lich-su-van-hoa	Lịch Sử - Văn Hóa	\N	\N	\N	0	2026-08-25 08:24:59.504833+00	2026-08-25 08:24:59.504833+00
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chat_messages (id, "sessionId", role, text, "createdAt") FROM stdin;
f1a288ca-1f52-4eaa-9ddf-457d5cd9fa6b	131cb125-e52b-4eb9-a18f-6d8bfdfba34d	user	Hi chào cậu nhaa chatbot	2026-08-21 08:08:14.674455+00
1c4a53d0-66aa-4695-b7a3-feb0472dc88d	131cb125-e52b-4eb9-a18f-6d8bfdfba34d	model	Chào cậu nha! Rất vui được gặp cậu. 👋\n\nMình là trợ lý tri thức của thư viện cá nhân của cậu đây. Cậu có cần mình giúp tìm sách, gợi ý đọc hay có câu hỏi nào không? Cứ tự nhiên hỏi nhé! 😊	2026-08-21 08:08:14.6959+00
3619401d-b278-4191-9b95-c44bbc487bf5	792cd902-a269-4ddf-b017-2b469383c316	user	Test lịch sử nhaaa	2026-08-21 08:08:41.974466+00
a95a940e-f21f-41ea-b343-95cc8b3ed0b8	792cd902-a269-4ddf-b017-2b469383c316	model	Chào bạn! Một bài "test lịch sử" thú vị quá! 😊 Lịch sử luôn là kho tàng của những câu chuyện và bài học giá trị.\n\nBạn có biết không, ngay cả những nhân vật vĩ đại trong lịch sử cũng phải trải qua quá trình rèn luyện để trở thành người truyền cảm hứng? Chẳng hạn như **Abraham Lincoln** – một trong những nhà lãnh đạo được kính trọng nhất. Ban đầu, ông cũng từng là người rất hay chỉ trích người khác, nhưng rồi ông đã học cách thay đổi, thể hiện sự đồng cảm và xây dựng lòng tin, từ đó nhận được sự yêu mến và lòng trung thành sâu sắc của mọi người.\n\nNhững câu chuyện như thế, về cách các vĩ nhân xưa đối xử với những người xung quanh để tạo nên thành công, chính là điều mà cuốn **"Đắc Nhân Tâm"** của Dale Carnegie trong thư viện của chúng ta khám phá rất sâu sắc đấy. Không chỉ là sách kỹ năng sống, cuốn sách này còn là một tập hợp các bài học lịch sử về nghệ thuật đối nhân xử thế nữa!\n\nHy vọng bạn thấy câu chuyện này thú vị! Có muốn hỏi thêm điều gì về lịch sử hay cuốn sách nào khác không?	2026-08-21 08:08:41.982478+00
b68c7a20-9547-4aaf-8532-25ac2d7104c7	beae9288-6f12-4092-b685-147aec140db7	user	Tui cần tư vấn về sách công nghệ có trong thư viện á	2026-08-21 09:54:30.952644+00
70dc3695-bb1b-4b7b-9e55-2c3276dddc1c	beae9288-6f12-4092-b685-147aec140db7	model	Chào bạn! Thật vui được hỗ trợ bạn khám phá thư viện của mình.\n\nTrong thư viện hiện tại, mình có 2 cuốn sách thuộc chủ đề Công nghệ rất đáng để bạn tham khảo:\n\n*   **"Clean Code"** của Robert C. Martin: Đây là một cuốn sách kinh điển dành cho các lập trình viên, tập trung vào việc viết code sạch, dễ đọc, dễ bảo trì và hiệu quả. Rất hữu ích nếu bạn muốn nâng cao kỹ năng lập trình của mình.\n*   **"Designing Data-Intensive Applications"** của Martin Kleppmann: Cuốn này đi sâu vào các nguyên tắc và kiến trúc để xây dựng các hệ thống xử lý dữ liệu quy mô lớn, bền vững và tin cậy. Nếu bạn quan tâm đến hệ thống dữ liệu, cơ sở dữ liệu và kiến trúc phân tán thì đây là lựa chọn tuyệt vời.\n\nHy vọng bạn sẽ tìm thấy những điều thú vị từ hai cuốn sách này nhé!	2026-08-21 09:54:30.964614+00
6e27c0a0-c6b5-4f9a-94e9-d8ff87571364	0352a0a1-f505-426c-a63c-a77cd4467611	user	thư viện có sách tài chính ko	2026-08-21 11:31:50.127728+00
18cc8ce4-8f76-4e65-a118-7c436922ad7e	0352a0a1-f505-426c-a63c-a77cd4467611	model	Chào bạn, đúng là thư viện mình có một cuốn sách về tài chính đó nhé:\n\n*   **"Người Giàu Nhất Thành Babylon"** của George Samuel Clason.\n\nCuốn sách này rất hay, giới thiệu những nguyên lý cơ bản về tài chính, cách làm giàu, tiết kiệm và quản lý tiền bạc từ thời Babylon cổ đại. Nó sẽ giúp bạn hiểu rõ cách "làm cho vàng sinh lợi" và xây dựng kế hoạch chi tiêu hiệu quả để đạt được sự sung túc đấy!	2026-08-21 11:31:50.135191+00
4270d908-6702-48b4-ab75-8fe599a6c55d	47434ea9-b71f-4a64-8d50-197e80305b32	user	Bạn nghĩ thư viện thiếu sách gì hông	2026-08-24 02:17:09.527234+00
14bca234-8d81-4716-9707-ae888bbd6184	47434ea9-b71f-4a64-8d50-197e80305b32	model	Chào bạn! Thư viện của bạn hiện có 15 cuốn sách rất chất lượng đó, đặc biệt là mảng **Tiểu Thuyết Văn Học** và **Trí Tuệ Cảm Xúc** đã có nhiều tựa sách sâu sắc.\n\nNếu để gợi ý thêm, mình nghĩ thư viện có thể bổ sung một số thể loại sau để làm phong phú hơn nữa nhé:\n\n*   **Sách Lịch sử hoặc Văn hóa:** Để mở rộng kiến thức về thế giới, các nền văn minh và dòng chảy thời gian. Thư viện mình hiện chưa có cuốn nào thuộc mảng này.\n*   **Khoa học phổ biến:** Những cuốn sách giúp bạn khám phá những điều thú vị về vũ trụ, tự nhiên, hoặc các ý tưởng khoa học một cách dễ hiểu. Chẳng hạn như "Sapiens: Lược Sử Loài Người" hay "Vũ Trụ Trong Vỏ Hạt Dẻ" (những cuốn này thư viện chưa có nhé).\n*   **Kinh doanh và Phát triển sự nghiệp chuyên sâu:** Ngoài cuốn **"Đắc Nhân Tâm"** về kỹ năng giao tiếp và **"Người Giàu Nhất Thành Babylon"** về tài chính, bạn có thể tìm thêm sách về chiến lược kinh doanh, marketing, quản lý dự án hay lãnh đạo hiện đại để phát triển sâu hơn trong sự nghiệp.\n\nChúc bạn có thêm nhiều cuốn sách hay cho thư viện của mình!	2026-08-24 02:17:09.541203+00
c66b495e-a472-4cd6-94a9-806571e04f2f	47434ea9-b71f-4a64-8d50-197e80305b32	user	tôi muốn add thêm sách về thiên văn học hoặc với lịch sử văn hóa loài người kiểu vậy, bạn thấy hợp lí k	2026-08-24 02:18:40.246089+00
68e0d9f9-05b4-4713-8d13-cade80ca04d5	47434ea9-b71f-4a64-8d50-197e80305b32	model	Chào bạn!\n\nĐây là một ý tưởng rất tuyệt vời để làm phong phú thêm thư viện của bạn đó!\n\nHiện tại, thư viện mình có 15 cuốn sách, tập trung vào các mảng **Tiểu Thuyết Văn Học**, **Trí Tuệ Cảm Xúc**, **Công nghệ**, **Kỹ năng sống** và **Tài chính**. Mình thấy chưa có cuốn nào chuyên sâu về **thiên văn học** hay **lịch sử - văn hóa loài người** cả.\n\nViệc bổ sung thêm những thể loại này sẽ rất hợp lý bởi:\n\n*   **Mở rộng tầm nhìn:** Giúp bạn khám phá những kiến thức rộng lớn về vũ trụ, hành tinh, hoặc hiểu sâu hơn về quá trình phát triển của các nền văn minh, văn hóa trên thế giới.\n*   **Cân bằng thư viện:** Thư viện sẽ trở nên đa dạng và toàn diện hơn, không chỉ tập trung vào phát triển bản thân và giải trí qua tiểu thuyết, mà còn cung cấp kiến thức nền tảng quan trọng.\n*   **Bổ trợ cho tư duy:**\n    *   Những cuốn sách như **"Tư Duy Nhanh Và Chậm"** hay **"Nghệ Thuật Tư Duy Rành Mạch"** mà thư viện đang có giúp rèn luyện cách suy nghĩ, và sách lịch sử, khoa học sẽ cung cấp thêm "dữ liệu" phong phú để ta áp dụng các kỹ năng tư duy đó.\n    *   Dù "Người Giàu Nhất Thành Babylon" có nhắc đến bối cảnh cổ đại và "Trường Ca Achilles" dựa trên thần thoại, nhưng trọng tâm của chúng là tài chính và văn học. Một cuốn sách lịch sử hay văn hóa chuyên biệt sẽ mang lại góc nhìn tổng quan và kiến thức sâu rộng hơn.\n\nMình gợi ý một vài cuốn sách hay thuộc thể loại này (những cuốn này thư viện mình **chưa có** nhé):\n\n*   **Lịch sử văn hóa loài người:**\n    *   **"Sapiens: Lược Sử Loài Người"** của Yuval Noah Harari: Một cuốn sách cực kỳ nổi tiếng, giúp bạn nhìn lại toàn bộ quá trình tiến hóa và phát triển của loài người.\n    *   **"Lược Sử Thời Gian"** của Stephen Hawking: Dù nghiêng về vũ trụ học, nó cũng chạm đến những câu hỏi lớn về sự tồn tại và lịch sử hình thành của vạn vật.\n*   **Thiên văn học/Khoa học phổ biến:**\n    *   **"Vũ Trụ Trong Vỏ Hạt Dẻ"** của Stephen Hawking: Khám phá những khái niệm phức tạp về vũ trụ một cách dễ hiểu.\n    *   Bất kỳ cuốn sách nào của Carl Sagan, ví dụ như **"Cosmos"**: Mang bạn du hành qua không gian và thời gian với những kiến thức và cái nhìn đầy chất thơ.\n\nChúc bạn có thêm nhiều lựa chọn thú vị cho thư viện của mình nhé!	2026-08-24 02:18:40.264457+00
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.chat_sessions (id, title, "createdAt", "updatedAt") FROM stdin;
131cb125-e52b-4eb9-a18f-6d8bfdfba34d	Hi chào cậu nhaa chatbot	2026-08-21 08:08:11.197145+00	2026-08-21 08:08:14.725021+00
792cd902-a269-4ddf-b017-2b469383c316	Test lịch sử nhaaa	2026-08-21 08:08:30.920879+00	2026-08-21 08:08:41.993317+00
beae9288-6f12-4092-b685-147aec140db7	Tui cần tư vấn về sách công nghệ có trong thư viện á	2026-08-21 09:54:26.119291+00	2026-08-21 09:54:30.977477+00
0352a0a1-f505-426c-a63c-a77cd4467611	thư viện có sách tài chính ko	2026-08-21 11:31:46.17328+00	2026-08-21 11:31:50.142972+00
47434ea9-b71f-4a64-8d50-197e80305b32	Bạn nghĩ thư viện thiếu sách gì hông	2026-08-24 02:16:57.436701+00	2026-08-24 02:17:09.568633+00
\.


--
-- Data for Name: diary_entries; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.diary_entries (id, author, title, content, mood, "createdAt", "updatedAt", "likedBy", "isPrivate", "photoUrl") FROM stdin;
57af370c-7213-4551-ac74-07bb3c4ffdc2	me	Hà Nội ngày trở gió	Hà Nội dạo này thời tiết thất thường\nTrở lạnh dần rồi\nEm ra đường nhớ mặc áo ấm nhé	yeu	2026-08-14 05:20:21.192211+00	2026-08-22 08:14:24.31415+00	partner	f	\N
95c3be4c-1a0c-4d35-9881-66846826e6e4	me	\N	Em à, anh nói này\n\nEm không đạo đức giả đâu, thật đấy. Em cũng không có lỗi với anh, không nợ anh gì cả. Không cần hứa hẹn gì hết, không cần đền anh gì hết nha.\n\nEm thức cả đêm chỉ vì áy náy với anh, anh không muốn vậy chút nào. Anh thật sự ổn mà, em đừng lo cho anh nữa.\n\nChỉ cần em chăm em cho tốt thôi, đó là điều anh mong nhất.\n\nNếu có đêm nào cảm thấy quá nặng nề mà không ngủ được, em cứ gọi cho người thân, hoặc nhắn cho bạn thân cũng được. Đừng cố gắng chịu đựng một mình nhé\n\nSáng nay em sao rồi. Có chợp mắt được chút nào không	\N	2026-08-15 03:26:17.2144+00	2026-08-15 05:58:12.988764+00	partner	f	\N
5680b7bb-be3a-47e1-a040-1d9895c663d6	me	12/08/2026	Hôm nay chốt lương rồi.\n\nMột tháng thử việc cũng xong. Con số ổn, đủ để tự lo cho mình, đủ để làm bước đệm cho những gì sắp tới. Là một ngày đáng vui.\n\nCó một khoảnh khắc theo phản xạ muốn nhắn cho em đầu tiên, rồi nhận ra không còn ai để nhắn nữa. Không sao cả. Vui một mình cũng là một dạng trưởng thành, học cách tự vỗ vai mình, tự nói "làm tốt lắm"...	vui	2026-08-12 07:13:34.798587+00	2026-08-22 08:14:21.872205+00	partner	f	\N
64b1512e-74e4-41c9-bf76-9df2f99509ec	partner	A di đà phật	Nam mô a di đà phật. Anh cứ như này thì không thoát ra được đâu, bình tĩnh đi nào. Sao cuộc sống của anh bận vậy mà anh vẫn nghĩ đến mấy chuyện này được. Lúc nào em bận cái là có khi bố mẹ em còn không gọi được em luôn ấy. Đó là sự ích kỷ của em, nên em thấy không đáng, thật sự rất là không đáng nếu anh cứ như thế này. Hay để em mở lại acc anh block em đi nhé, vậy chắc sẽ thoải mái hơn. Đằng nào fb cũng cho em 30 ngày để suy nghĩ lại nên vẫn mở acc được, threads thì em xóa rồi, ins thì khóa thôi vì đằng nào cũng phải mở lại để học không đứa bạn qua mạng chửi lún đầu mất, hoặc dùng acc prv fl nó vì em có acc prv đăng linh tinh không cho ai xem. Nói chung cuộc sống của em thì vẫn thế thôi, nghĩ nhiều nên viết nhiều. \nAnh sẽ ổn thôi, thật đó. Khéo em là nghiệp mà anh phải gặp đấy, qua được thì anh sẽ tốt hơn thôi. Thật ra cuộc sống của em chưa từng ổn định đâu, với cả em cũng lông bông lắm, từ trong suy nghĩ đã vậy rồi. Khéo ra trường mà suôn sẻ thì em sẽ vào Sài Gòn chứ không ở lại Hà Nội đâu. Bố mẹ muốn em về quê, bạn bè em ai cũng thế, học xong sẽ về quê hết. Còn em chưa từng nghĩ sẽ ở lại đây, càng không nói tới việc về quê. Em sẽ làm việc và sống ở nơi khác, không đi tu thì em sẽ vào Sài Gòn sống, còn em mà đi tu thì ở Bắc Ninh haha. \nTrước xem bói linh tinh mấy chỗ ngta đều bảo em sẽ sống một mình nma không tin lắm, giờ thì bắt đầu tin rồi, đằng nào em cũng chưa từng đặt tình cảm lên đầu. Em thấy em đủ khả năng sống một mình, em chả bao giờ dựa dẫm vào ai cả, trước giờ tâm sự em cũng chỉ nói với 1 đứa bạn với đứa em gái, à hôm trước có kể vài chuyện với o của em nữa, o là em của bố, chỗ em gọi là thế. Sau này  gặp nhiều người hơn, anh sẽ thấy được em của bây giờ ích kỷ cỡ nào. Vậy nên là bỏ lại quá khứ và bước tiếp đi. Vốn dĩ bây giờ anh cũng đã rất tốt đẹp, em tin anh rồi sẽ hạnh phúc thôi.	binh-yen	2026-08-14 12:32:30.881938+00	2026-08-14 17:36:34.511287+00	me	f	\N
8e8dab20-f9b2-4939-a985-758de3cfd85b	me	\N	Em đừng xin lỗi nữa. Anh sẽ không nói dối là anh hết thương em, nhưng anh cũng giữ đúng những gì đã nói với em hôm ấy. Xin lỗi hay chúc anh hạnh phúc kiểu đó cũng không đổi được gì, chỉ làm em và anh thêm nặng lòng.\n\nChuyện anh còn thương là phần của anh, em không cần phải làm gì với nó cả. Anh không hẹn em điều gì, cũng không mong đợi gì ở em. Mình đã quyết rồi, cứ vậy thôi.\n\nNhưng cũng không phải vĩnh biệt gì mãi mãi đâu. Mình vẫn có thể gặp nhau, nói chuyện bình thường. Em cần tâm sự gì thì cứ nói với anh, anh không chắc mình có lời khuyên gì hay ho, nhưng nghe thì anh nghe được.	\N	2026-08-15 11:07:05.800499+00	2026-08-15 14:25:07.396029+00	partner	f	\N
1ffbb8d5-c723-4af0-a7b1-760946b0ee95	me	Duyên	Hồi bé anh ở với ông bà. Bố mẹ đi làm xa, mỗi năm về vài lần. Anh lớn lên trong khoảng cách đó, không phải thiếu thương, chỉ là thiếu người bên cạnh.\n\nCó một dạo anh nghĩ đến việc đi tu. Anh mê những bộ phim về Thiếu Lâm, về các vị hòa thượng, về chùa chiền. Anh thích cái không khí trong đó, thanh tịnh, bình yên, người ta sống chậm, sống có tình, giúp người giúp đời mà không đòi hỏi gì. Với một đứa trẻ lớn lên thiếu người bên cạnh, những hình ảnh đó ấm áp lạ thường.\n\nTrong số những bộ phim đó, anh ấn tượng nhất với Tế Công - phần có Yên Chi. Trước khi thành Tế Điên hòa thượng, ông có tên là Lý Tu Duyên. Tu Duyên và Yên Chi thương nhau, nhưng duyên không đủ, Tu Duyên đã chọn con đường tu hành. Đến kiếp sau, hai người vô tình gặp lại. Yên Chi không còn nhớ gì về Tu Duyên nữa. Còn Tế Điên thì nhớ tất cả.\n\nAnh xem đến đoạn đó thì khóc. Không phải vì buồn theo kiểu bi lụy, mà vì thấy có một loại tình cảm đẹp đến mức không cần được ở bên nhau. Chỉ cần một người còn nhớ là đủ. Chỉ cần từng có nhau một lần, ở một kiếp nào đó, cũng đủ để mối tình ấy có ý nghĩa.\n\nNgười ta nói hữu duyên thiên lý năng tương ngộ, vô duyên đối diện bất tương phùng. Có lẽ mọi cuộc gặp trên đời này đều đã được sắp đặt sẵn từ một nơi nào đó.\n\nAnh đã để ý định đi tu trong lòng, không thực hiện. Vì anh nghĩ cuộc đời còn nhiều điều đáng học, đáng khám phá. Nhưng câu chuyện Tu Duyên và Yên Chi vẫn ở lại trong anh, như một cách nhìn về tình yêu mà anh vẫn giữ đến bây giờ.\n\nĐợt này nghĩ lại, thấy có gì đó rất giống mình.\n\nCảm ơn vì mình đã từng có nhau..	binh-yen	2026-08-14 15:07:41.431826+00	2026-08-14 17:02:51.886356+00	partner	f	\N
63946872-17f5-4f00-98ca-07346e472ab3	partner	\N	Hay rồi đó, đừng có mà làm em lụy, trước giờ đời em chưa có lụy cái gì hay ai đâu=))) Em mà đi tu thì là vì em trốn tránh cuộc đời thôi, em nói thật, tại có lý do để em làm thế mà. Còn không thì bây giờ em đang học trong SG ấy, vốn dĩ em chưa từng muốn ra HN đâu. Sao thấy thích cái web này quá cảm giác như viết nhật ký ấy hh. \nKể cho nghe, tâm lý em có vấn để từ hồi cấp 1 ấy, à nhưng không phải theo kiểu bị điên đâu, nhưng không biết có được liệt vào tâm thần không thì không chắc. Anh biết không thật ra em từng có hành vi self harm đó, như cái bạn đợt em kể anh ấy, bây giờ người em vẫn còn sẹo mà có một số chỗ nó lộ ra nên thề là em siêu ngại nếu người khác thấy được. Em bắt đầu làm tham vấn tâm lý từ đầu năm nhất tới giờ, nhưng em học được cách là cho ngta thấy rằng em ổn và em cũng tự cho rằng là em ổn. Ôi nói chung em kinh khủng lắm, nhưng hôm em đọc được bài bảo là mấy người như em nếu không có chịu trị liệu cho khỏi thì người bị bệnh tiếp theo sẽ là người bên cạnh em, cái em tỉnh luôn=)) em nhận ra em sẽ vô thức áp mấy cái cách đối xử mà em không thích lên người thân. Mà anh biết không, Khổng Tử có câu: "Kỷ sở bất dục, vật thi ư nhân" nghĩa là điều gì bản thân mình không muốn thì đừng làm cho người khác. Em không thích mấy cái kiểu vậy, nhưng em sống trong đó, em trở thành kiểu người như vậy lúc nào em cũng chẳng biết nữa, sai quá sai mà không chịu thay đổi. \nAnh thiếu người bên cạnh, còn em có rất nhiều người bên cạnh nhưng em chỉ muốn đẩy người ta ra khỏi cuộc sống của em thôi. Em cảm thấy rất xấu hổ với anh, vì anh tốt quá, còn em thì kinh khủng quá trời. O em bảo là em phải biết yêu bản thân em đã thì em mới yêu người khác được, nhưng em chưa từng yêu em, em mà yêu em thì em đã không muốn chết. Em hỏi rất nhiều người, hỏi cả sư nữa, em không hiểu "yêu" là gì cả, em nghĩ cả đời này có lẽ em cũng sẽ không hiểu được. Thôi kệ, đại đại vậy đi. Em hy vọng anh hạnh phúc và em sẽ chia cho anh một ít phước mỗi lần em tụng kinh xong hihi. Mong anh mạnh khỏe, anh khỏi cần nghĩ mấy cái như thay đổi thời tiết em ốm hay gì, em sống hơi bị dai, có mà anh sức đề kháng kém quá trời kém ra ấy. Anh giữ sức khỏe nhé, mong anh bình an. A di đà phật, gặp trúng kiểu người như em không có nghĩa là ai cũng sẽ kì quặc như vậy nhé. Em xin lỗi anh nhiều.	\N	2026-08-14 17:11:54.519838+00	2026-08-14 17:36:27.561345+00	me	f	\N
63788a63-a137-4bbc-862e-218723e1ffac	partner	\N	Em cảm ơn và cũng xin lỗi anh rất nhiều	\N	2026-08-14 17:49:02.961473+00	2026-08-14 17:50:04.222739+00	me	f	\N
ef1f493d-2848-41c5-bdc5-90f32984c358	me	\N	Cảm ơn em đã kể anh nghe.\n\nAnh không dám nói anh hiểu hết, vì đó là những điều em đã sống với chúng nhiều năm.\n\nĐiều em nói về bản thân em, anh không thấy vậy. Anh thấy em đang cố gắng, và đó là điều đáng quý.\n\nEm nói em từng không muốn sống - anh nghe câu đó rồi, và anh mừng vì em vẫn đang ở đây, vẫn đang trị liệu. Em cứ tiếp tục nhé.	\N	2026-08-14 17:39:30.199728+00	2026-08-14 17:59:21.314723+00	partner	f	\N
3577dc74-36b3-47df-b8c1-c68d1b93e0df	partner	\N	Ôi mắc uống rượu quá mà quy y rồi hh, hồi năm nhất em hay uống linh tinh với bạn lắm. Nhiều khi không biết mình đang tìm cái gì nữa cơ, nó mông lung thật sự. Biết đâu sau này mọi người ổn định gia đình, cuộc sống hết rồi em vẫn lông bông đi tìm. Anh phải hạnh phúc nhé, anh mà không hạnh phúc em thấy em phải đi tu gieo duyên luôn ấy. Em chỉ cầu em không có kiếp sau thôi, không chắc nghiệp chết em mất. Anh tốt kinh khủng, không có điểm nào để chê, chắc chê cái hơi xui khi gặp phải em. Dạo này bạn cùng phòng em có người yêu rồi, có bạn gái, les hết ba đứa, một đứa vừa từ Yên Bái xuống gặp ng yêu bên Đài về. Em tò mò thật sự, có thể anh sẽ giống bạn em bảo em vô tâm, nhưng thật sự em chưa từng có cảm giác mong chờ một ai, kể cả bố mẹ em, em như bị vô cảm ấy. Người như em giống như được định sẵn là sẽ sống một mình rồi. Nhưng anh thì không có vậy, anh có tình cảm, anh có cái nhiệt huyết dành cho tình yêu, còn em chỉ có sự ích kỷ. Bây giờ em mới hiểu được điều đó, thành ra em cũng hơi ngưỡng mộ anh hh. Vậy nên em tin anh rồi sẽ thật hạnh phúc thôi, hy vọng mọi thứ sẽ thật suôn sẻ với anh và em mong anh bình an.	\N	2026-08-14 17:33:13.148049+00	2026-08-14 17:50:04.928592+00	me	f	\N
7c4ceac1-e301-4920-9c89-f993678e41fc	me	\N	Em nói em cầu không có kiếp sau. Anh không có câu trả lời hay lời khuyên nào cả, chỉ muốn em biết là anh nghe được, và câu đó không rơi vào khoảng không.\n\nEm nói em vô cảm, em ích kỷ, anh không nghĩ vậy. Người vô cảm không viết ra được những gì em vừa viết cho anh. Người ích kỷ không lo cho anh đến mức đùa sẽ đi tu gieo duyên nếu anh không hạnh phúc. Em có tình cảm nhiều hơn em nghĩ về mình á\n\nAnh sẽ cố sống tốt. Không phải để em khỏi phải gieo duyên, mà vì đó là điều đúng đắn cần làm.\n\nEm cũng vậy nhé. Cứ tiếp tục trị liệu, cứ giữ o em, giữ sư, giữ bạn em bên cạnh. Em không một mình đâu, dù có lúc em cảm thấy vậy\n\nNgủ ngon em nhé	\N	2026-08-14 17:47:02.333212+00	2026-08-14 17:59:16.512004+00	partner	f	\N
40e6e5b2-6b12-4ccc-8955-12079e169ace	partner	\N	Em xin lỗi anh, em thấy em có lỗi với anh nhiều quá, cảm giác có xin lỗi bao lần vẫn không đủ. Cảm giác bứt rứt mà tội lỗi quá, hay em hứa sau em chỉ yêu con gái thôi nha. Hay anh có gì muốn làm hay thích gì cần gì không, em thấy có lỗi quá không ngủ được.	\N	2026-08-14 19:38:17.750532+00	2026-08-15 04:23:45.537988+00	me	f	\N
401153ea-db8e-4601-b10c-920bf1052ffc	partner	\N	Em đau lòng quá, em xin lỗi anh, cảm giác đạo đức giả thật.	\N	2026-08-14 21:34:05.929036+00	2026-08-15 04:25:29.315899+00	me	f	\N
fcd78de0-53e6-4879-8d98-0389b817a89a	partner	\N	Nay em không ngủ, giờ đang trên lớp ấy. Em có năng lực vượt trội trong việc thức khuya mà, có khi 2 ngày không ngủ em vẫn bình thường , chất lắm=))) \nEm mong anh hạnh phúc, em cảm ơn và thật lòng xin lỗi anh rất nhiều ạ	\N	2026-08-15 05:58:05.51292+00	2026-08-15 07:54:04.007703+00	me	f	\N
30542d72-96bb-4c01-b537-ef5668000134	me	\N	Em à, anh nói nè.\n\nChuyện với mẹ, mẹ nào cũng có kiểu thương con riêng, và mẹ em rõ ràng thương em nhiều lắm mới sốt ruột đến vậy. Nhưng em à, không muốn kết hôn không có nghĩa là em ích kỷ đâu, hai chuyện đó khác nhau. Em có quyền chọn cách sống của mình, và cách nào cũng có thể đủ, có thể vui, miễn là em thật sự chọn nó. Từ từ rồi mẹ cũng sẽ hiểu. Còn giờ mẹ chưa hiểu, thì em cũng đừng vội tin những gì mẹ nói lúc đang bực.\n\nCòn cái em viết kiểu em xấu, em ích kỷ, người xấu chỉ có em thôi, anh đọc mà thương. Em đang mệt nên em nghĩ về mình khắt khe vậy thôi. Anh cũng không dám nói là anh hiểu em nhiều đâu, mình quen nhau có bao lâu, nhưng cứ nhìn cách em lo cho anh, cách em sợ làm khổ người khác, tự nó cũng đủ nói em không phải người xấu rồi em à.\n\nCòn chuyện em bảo anh đừng liên lạc nữa, em đừng lo cho anh mấy phần đó, anh sẽ tự biết chừng mực của mình. Còn phía em, khi nào em cần một người ngồi nghe, thì anh vẫn ở đây.\n\nĐi trekking nhớ giữ sức nha em. Mang đủ nước, đi cùng người quen thì anh cũng yên tâm hơn.	\N	2026-08-15 18:45:39.725455+00	2026-08-18 13:25:52.006591+00	partner	f	\N
378f1a30-3fc9-4032-804c-daa298185f1a	partner	\N	Em cảm ơn anh, anh làm em càng thêm chắc chắn về tương lai của em rồi đó. Nãy gọi mẹ em có lấy ví dụ về một người giống như anh, mẹ bảo em không yêu thì bạn em yêu anh=)))) người thiệt chỉ có em làm em mắc cười quá. Em kể vu vơ để nói chuyện sau này em không kết hôn và be bét luôn anh ạ, mẹ sấy em nãy giờ.  \nNhưng mẹ em nói đúng thật mà, anh sẽ gặp được người tốt, còn em thì theo lời mẹ là sau ế đến già tại kén chọn hh. Tại trước bố mẹ em cứ chê em khó tính này kia không chịu sửa thì không ai thích cái em mới kể mấy người thích em với bố mẹ, xong hai người mặc định là em cực kì khó tính, kén chọn, lấy ví dụ là bác hàng xóm hồi trẻ như này như kia xong lớn tuổi không ai lấy.\nMẹ em nhắn thẳng cho em là em ích kỷ mà, em với bố mẹ cãi nhau rồi chiến tranh lạnh rất nhiều vì mấy chuyện như này. Kinh khủng lắm anh, em không hiểu tại sao con người ta cứ phải mặc định là kết hôn thì cuộc đời mới viên mãn. Bây giờ một người như em mà kết hôn chẳng phải khổ chết người kia à. Khéo em sẽ thành một đứa con bất hiếu mất anh ạ, cảm giác bị trói buộc cả đời dù có lựa chọn hướng đi nào đi chăng nữa. Anh chẳng cần trả lời em đâu, hoặc anh không cần vào đây làm gì đâu, cho mỗi em viết thôi. Nếu anh muốn bước tiếp, anh không nên có liên lạc gì với em nữa, thứ nhất là anh sẽ khó dứt ra, thứ 2 sẽ làm người mới tổn thương anh ạ. \nEm giờ thoải mái lắm, thật, giờ ai cũng biết em có người yêu, em không đính chính gì cho phiền đâu đằng nào tụi nó cũng không biết anh nên sẽ không phiền tới anh. Giờ em sẽ mang cái mác này tới đâu thì tới, tránh được biết bao thứ phiền phức hh. Với em biết trong đám bạn ở ins của em có đứa ghen tị nên cứ để vậy đi đằng nào em cũng thích hơn thua, em chả ưa nó mấy. Anh không biết đâu, trong câu chuyện em kể về anh với bạn em anh là một người siêu siêu tốt, vậy nên người xấu chỉ có em thôi, vì thật ra em cũng có tốt đẹp mấy đâu. \nTuần sau nữa em đi trekking, em đi với thg Tuấn, không biết nó có rủ thêm được ai không, em cũng chả quan tâm mấy, chủ yếu giờ em chỉ muốn đi hít thở thôi. Với cả em thích anh, em không thích nó đâu, em với nó chơi cùng 2 đứa cgai nữa một đứa Đà Nẵng một đứa Huế ấy. Em chọn dừng lại vì em chắc chắn rằng sau này em sẽ làm tổn thương anh mà em không biết chứ em thề em không có thích đứa khác, không hiểu sao nhưng em cảm giác em phải thề vậy, mà có thích ai cũng không bao giờ thích cái thằng khỉ gió đó được. Em chơi với nó từ lớp 6 vì bố mẹ bọn em là giáo viên dạy chung trường thôi, chuyên giám sát nhau khổ v ra.	\N	2026-08-15 14:21:56.268631+00	2026-08-16 03:14:03.842094+00	me	f	\N
8d64139d-1893-4d4c-a449-3b4adac436ec	me	\N	Anh coi thấy sắp bão rồi á\nVài hôm nữa em đi cẩn thận nhé\nMong là hôm đó trời quang mây tạnh	\N	2026-08-18 18:19:09.670708+00	2026-08-19 07:13:45.996491+00	partner	f	\N
d4abf73e-1cb9-404c-ab0d-5fe3b3e8f838	me	\N	I miss u	\N	2026-08-20 10:00:37.299918+00	2026-08-20 10:00:37.299918+00	\N	t	\N
f3e3d73d-2cb4-4ad8-afce-8d764d383773	me	\N	tui nho b	\N	2026-08-20 10:39:17.985295+00	2026-08-20 10:39:17.985295+00	\N	t	\N
6cd7c12b-5f0a-4585-9d32-1185d019af21	partner	\N	Sợ ở Hà Nội thì không mưa cái tới nơi mưa thì chết=)) khéo nó vẫn bắt mặc áo mưa leo thì thôi, ra dại	\N	2026-08-19 07:13:42.928871+00	2026-08-23 18:17:01.440817+00		f	\N
f1bd142d-5577-43a5-9fd9-61df5f6b2824	partner	\N	Ủa nhưng sao anh biết nay em thi vậy, em có kể r à	\N	2026-08-23 06:42:28.161874+00	2026-08-24 09:57:59.982119+00	me	f	\N
9c959529-ef1d-4efa-a6a7-687d8a312d11	partner	\N	À em không đi nữa, mưa nên dời lịch rồi	\N	2026-08-22 07:40:58.895261+00	2026-08-24 09:58:04.563077+00	me	f	\N
587073cf-4cbd-4b7a-95ec-cfe4c6b87187	me	22/08/2026	Mai em thi môn cuối mà nhỉ\nEm thi tốt nha\nVới lại là đi trekking nhớ mang theo đủ đồ đó, anh thấy tin bão số 4 rồi	\N	2026-08-22 07:27:54.795695+00	2026-08-22 07:58:48.354289+00	partner	f	https://book-api.dangpham.id.vn/api/files/diary/fd50dcac-d578-4137-b319-6d9970eeb6e9.png
f0c4bdce-0c9c-4f73-a7b6-343b63c4c44f	me	\N	Em thi về rùi thì tranh thủ nghỉ ngơi đi nhée	\N	2026-08-23 05:50:05.101532+00	2026-08-23 05:50:16.409109+00	\N	f	\N
be089407-655f-4ccd-96b3-d462977d4fdd	me	\N	Cũng không nhớ nổi tại sao biết nữa, chắc quen rồi nên mấy chuyện của em anh vẫn tự động để ý thôi. Mà thôi không quan trọng, thi xong là tốt rồi, nghỉ ngơi nhiều vào em nha	\N	2026-08-23 07:16:02.076732+00	2026-08-24 15:38:48.162408+00	me	f	\N
\.


--
-- Data for Name: memories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.memories (id, title, description, "memoryDate", "photoUrl", "addedBy", "createdAt", "youtubeId", "likedBy") FROM stdin;
9479111a-34b1-4dbb-8d94-2d53d92dccd8	Lần đầu gặp nhau	\N	2026-08-01	\N	me	2026-08-22 08:10:53.890771+00	LEUxrubc3Po	me
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.notifications (id, text, read, "createdAt") FROM stdin;
4532609e-6bfb-46f1-970d-faa09ddee9c4	Dang vừa thêm nhật ký mới	t	2026-08-21 09:25:12.258285+00
ea996b12-dbcc-459a-8cd6-537f75282066	Đã thêm sách mới: "Người Giàu Nhất Thành Babylon"	t	2026-08-21 11:20:12.319802+00
0185e658-25b8-47e3-b729-5cbc53b51b1c	Dang vừa thêm nhật ký mới	t	2026-08-22 07:27:54.826196+00
a6c8c98d-10b8-4497-8a51-dc73f5458493	Vy vừa thêm nhật ký mới	t	2026-08-22 07:40:58.919786+00
19cdd1cd-7688-4959-a7f5-36edcdcaee36	Dang vừa thêm nhật ký mới	t	2026-08-21 17:43:33.089316+00
8b5e19b7-936c-4715-9048-d3bc31233505	Dang vừa thêm nhật ký mới	t	2026-08-22 09:07:46.175387+00
8c487407-bc64-4fd2-aaa7-c513135bf809	Dang vừa thêm nhật ký mới	t	2026-08-22 09:41:23.1992+00
1631cafc-35f5-46bb-a89e-ef2f1c4effcd	Dang vừa thêm nhật ký mới	t	2026-08-22 09:41:54.742558+00
54a40362-a2af-4ba9-aed9-2acaffe8440e	Dang vừa thêm nhật ký mới	t	2026-08-22 11:23:51.883361+00
df969a49-39be-4ee4-a8b2-0bb7f3ab92bf	Dang vừa thêm nhật ký mới	t	2026-08-22 11:56:30.611669+00
99e6c3c9-1644-473b-b13c-3f7c18b5bb5c	❝ Nếu biết trăm năm là hữu hạn\nCớ sao ta không sống thật sâu ❞ — trích từ "Nếu biết trăm năm là hữu hạn"	t	2026-08-22 13:00:00.177195+00
3c0949c6-3d28-400a-a0db-08b4ee793e1f	Dang vừa thêm nhật ký mới	t	2026-08-23 05:50:05.142415+00
20589327-92bd-4a94-9457-fe9c994f63a3	Vy vừa thêm nhật ký mới	t	2026-08-23 06:42:28.196282+00
92e180d6-9dc9-4063-b21a-a93c2c1adee8	Dang vừa thêm nhật ký mới	t	2026-08-23 07:16:02.105475+00
2156f65c-0b9d-4c57-aaa9-8baf50fd0d22	Dang vừa thêm nhật ký mới	t	2026-08-25 04:06:09.26182+00
4d5a3611-7d3c-4769-98ac-49d75b972d30	Dang vừa thêm nhật ký mới	t	2026-08-25 04:02:51.075105+00
d10025da-9884-4d8a-8923-cdb3dd32e39e	Đã thêm sách mới: "Sapiens: Lược Sử Loài Người"	t	2026-08-25 08:33:12.166609+00
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.push_subscriptions (id, endpoint, p256dh, auth, "createdAt") FROM stdin;
ef950e85-2591-4b30-b402-c07351965974	https://fcm.googleapis.com/fcm/send/cRePb-feGLs:APA91bEUXlZNi1c-34Lay3PH5Ko4vlMqRqRRwDtDeOaQCjDcGFx4A2R4JRO89TfCCoGxZVbSBd_5gTCmuROfnLnAXvFYCLQViKN3Oz-RS8IXwGgvUxupbUSglcosUddpzp_stpflIgNn	BHHPTFYww3vRIUvepC3acU32ecTD8vyXAOtDDHnfyLuGPdehSsK-q4LWso1JsBiCqqDuxR8qfCnj8CxtAwU-iis	ov2kGRS4flkSEAYrF0Gh3A	2026-08-22 10:39:58.836025+00
f24ee9d1-1a32-468c-b7f6-8f563009f879	https://fcm.googleapis.com/fcm/send/c-AEAgIGe-Y:APA91bEBurqHvyoJsJHNQysvE-gieqYFHbkbywv2lx5lgU36nYL_1hMChZ8lUUzgv2tRuAI4mnbNtUylu26DkJzhOoOODi1kmA974JRgY5jzBxHwl2m_VUfSX1OTqNPF9CFkuf_2nJYR	BE9mH_VoTdeNwpNGYutF6ESm9nvDziiKPwijC-06tpYMcJSu1iNJDYEMbYN7owx7EvoMO5Am5vKXQrGsSRbm7io	puVX-k3QvaVdYH0fnS-qxw	2026-08-25 04:02:37.349334+00
\.


--
-- Data for Name: reminder_state; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.reminder_state (id, "lastStalledBookAt", "lastQuietDiaryAt", "lastQuoteResurfaceAt") FROM stdin;
1	\N	\N	2026-08-22 13:00:00.192+00
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.site_settings (id, "siteTitle", "curatorName", "curatorRole", "curatorPhoto", "updatedLabel", "partnerName", "updatedAt") FROM stdin;
1	Thư Viện	Dang	Góc nhỏ riêng của tụi mình - Hai Dang, Le Vy	https://i.pinimg.com/originals/3b/32/1a/3b321acf7afa27274eda02c5e0730391.png	2026	Vy	2026-08-14 05:20:21.192211+00
\.


--
-- Name: categories PK_24dbc6126a28ff948da33e97d3b; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_24dbc6126a28ff948da33e97d3b" PRIMARY KEY (id);


--
-- Name: chat_messages PK_40c55ee0e571e268b0d3cd37d10; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT "PK_40c55ee0e571e268b0d3cd37d10" PRIMARY KEY (id);


--
-- Name: diary_entries PK_45cc0613be17fab8a954db677a0; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.diary_entries
    ADD CONSTRAINT "PK_45cc0613be17fab8a954db677a0" PRIMARY KEY (id);


--
-- Name: notifications PK_6a72c3c0f683f6462415e653c3a; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "PK_6a72c3c0f683f6462415e653c3a" PRIMARY KEY (id);


--
-- Name: push_subscriptions PK_757fc8f00c34f66832668dc2e53; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "PK_757fc8f00c34f66832668dc2e53" PRIMARY KEY (id);


--
-- Name: book_quotes PK_9a0557edde98f289725aef3b46b; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.book_quotes
    ADD CONSTRAINT "PK_9a0557edde98f289725aef3b46b" PRIMARY KEY (id);


--
-- Name: reminder_state PK_9c4566c3b253a09134447379bfe; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.reminder_state
    ADD CONSTRAINT "PK_9c4566c3b253a09134447379bfe" PRIMARY KEY (id);


--
-- Name: memories PK_aaa0692d9496fe827b0568612f8; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.memories
    ADD CONSTRAINT "PK_aaa0692d9496fe827b0568612f8" PRIMARY KEY (id);


--
-- Name: author_locks PK_bbc608ac381f7f1a1ea67e7e9f6; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.author_locks
    ADD CONSTRAINT "PK_bbc608ac381f7f1a1ea67e7e9f6" PRIMARY KEY (author);


--
-- Name: book_reviews PK_cf9cfb9b88fef89b9d747b513d3; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.book_reviews
    ADD CONSTRAINT "PK_cf9cfb9b88fef89b9d747b513d3" PRIMARY KEY (id);


--
-- Name: site_settings PK_e4290e8371a166d7e066d131f6e; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT "PK_e4290e8371a166d7e066d131f6e" PRIMARY KEY (id);


--
-- Name: chat_sessions PK_efc151a4aafa9a28b73dedc485f; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT "PK_efc151a4aafa9a28b73dedc485f" PRIMARY KEY (id);


--
-- Name: books PK_f3f2f25a099d24e12545b70b022; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT "PK_f3f2f25a099d24e12545b70b022" PRIMARY KEY (id);


--
-- Name: push_subscriptions UQ_0008bdfd174e533a3f98bf9af16; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "UQ_0008bdfd174e533a3f98bf9af16" UNIQUE (endpoint);


--
-- Name: categories UQ_420d9f679d41281f282f5bc7d09; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "UQ_420d9f679d41281f282f5bc7d09" UNIQUE (slug);


--
-- Name: book_quotes FK_2bc22694ba147b088bdbe16fa98; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.book_quotes
    ADD CONSTRAINT "FK_2bc22694ba147b088bdbe16fa98" FOREIGN KEY ("bookId") REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: books FK_a0f13454de3df36e337e01dbd55; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT "FK_a0f13454de3df36e337e01dbd55" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: book_reviews FK_a7b2ddc7da0f98b88ed04ece7e0; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.book_reviews
    ADD CONSTRAINT "FK_a7b2ddc7da0f98b88ed04ece7e0" FOREIGN KEY ("bookId") REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: chat_messages FK_a82476a8acdd6cd6936378cb72d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT "FK_a82476a8acdd6cd6936378cb72d" FOREIGN KEY ("sessionId") REFERENCES public.chat_sessions(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict NRH0HNfj5lF0n1BSH4JhbwSjYCmKOEy0oVejenhtNhMHPlcolaQbyyQdnQ60uWT

